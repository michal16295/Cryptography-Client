const api = {
  //auth
  AUTH: "/auth/exchangeKeys",
  SET_PASS: "auth/setPass",

  //chat
  SEND_MESSAGE: "/chat/sendMsg",
  GET_MESSSAGES: "/chat/getMessages",
};
export default api;
