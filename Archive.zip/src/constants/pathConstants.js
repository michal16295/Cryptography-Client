const paths = {
  // Users
  CHAT: "/chat",
  HOME_PAGE: "/",
};

export default paths;
